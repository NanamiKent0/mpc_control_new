"""High-level supervisor entrypoints for compiling turn requests."""

from __future__ import annotations

from ..estimation import build_estimate_bundle
from ..models.task_types import TaskGraphSpec
from ..orchestration.graph_factories import build_turn_autonomous_graph_from_plan
from ..orchestration.turn_plan_graph_adapter import TURN_WORKFLOW_ORDERED_MODULES
from ...runtime_integration.observation_types import RuntimeObservationFrame
from .front_cooperation_plan import FrontCooperationPlan
from .turn_planner import plan_turn_workflow

TURN_TASK_SUPERVISOR_SOURCE = "control_core.supervisor.turn_task_supervisor"


def compile_turn_autonomous_request(
    frame: RuntimeObservationFrame,
    *,
    graph_id: str | None = None,
) -> tuple[FrontCooperationPlan, TaskGraphSpec]:
    """Compile one runtime-frame turn request into plan plus executable graph."""
    estimate_bundle = build_estimate_bundle(
        frame,
        ordered_modules=TURN_WORKFLOW_ORDERED_MODULES,
    )
    plan = plan_turn_workflow(estimate_bundle)
    graph_spec = build_turn_autonomous_graph_from_plan(
        plan,
        graph_id=graph_id,
        metadata={
            "runtime_input_mode": "runtime_frame",
            "runtime_dispatch_mode": "scheduler_envelope",
            "runtime_main_path": True,
            "turn_task_supervisor_source": TURN_TASK_SUPERVISOR_SOURCE,
            "estimate_bundle_source": estimate_bundle.diagnostics.get("estimate_bundle_source"),
            "estimate_bundle_timestamp_ns": estimate_bundle.timestamp_ns,
            "estimate_bundle_ordered_modules": list(
                estimate_bundle.diagnostics.get("ordered_modules", TURN_WORKFLOW_ORDERED_MODULES)
            ),
        },
    )
    return (plan, graph_spec)


__all__ = [
    "TURN_TASK_SUPERVISOR_SOURCE",
    "compile_turn_autonomous_request",
]
